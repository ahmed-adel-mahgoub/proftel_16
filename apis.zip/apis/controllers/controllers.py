import json
from datetime import datetime
from pickle import FALSE

from odoo import http, fields

from odoo.http import request
import logging

_logger = logging.getLogger(__name__)


class Apis(http.Controller):

    @http.route('/v1/api/attendance/get/email/<string:work_email>', type='http',
                auth="public", methods=['GET'], csrf=False)
    def get_attendance_email(self, work_email):
        try:
            users = request.env['hr.attendance'].sudo().search(
                [('email', '=', work_email)])
            if not users:
                return request.make_json_response({
                    "error": "table is empty",
                }, status=400)
            return request.make_json_response([{
                "id": user.id,
                "employee_id": user.employee_id.name,
                "work_email": user.email,
            } for user in users], status=200)

        except Exception as error:
            return request.make_json_response({
                "error": error
            }, status=400)

    @http.route('/v1/api/attendance/get/all', type='http', auth="public",
                methods=['GET'], csrf=False)
    def get_attendance_email_all(self, **kwargs):
        try:
            # Get all attendance records
            attendances = request.env['hr.attendance'].sudo().search([])

            if not attendances:
                return request.make_json_response({
                    "message": "No attendance records found",
                    "count": 0,
                    "data": []
                }, status=200)

            # Prepare response data
            result = []
            for attendance in attendances:
                employee = attendance.employee_id
                result.append({
                    "attendance_id": attendance.id,
                    "employee": {
                        "id": employee.id,
                        "name": employee.name,
                        "work_email": employee.work_email,
                        "department": employee.department_id.name if employee.department_id else None,
                    },
                    "check_in": attendance.check_in if attendance.check_in else None,
                    "check_out": attendance.check_out if attendance.check_out else None,
                    "worked_hours": attendance.worked_hours if attendance.worked_hours else 0,
                    "employee_image": attendance.employee_image,
                    "place_image": attendance.place_image,
                    "user_in_image": attendance.user_in_image,
                    "place_in_image": attendance.place_in_image,
                    "user_out_image": attendance.user_out_image,
                    "place_out_image": attendance.place_out_image,
                    "lat_check_in": attendance.lat_check_in,
                    "long_check_in": attendance.long_check_in,
                    "lat_check_out": attendance.lat_check_out,
                    "check_in_map": attendance.check_in_map,
                    "check_out_map": attendance.check_out_map,
                    "x_check_out_map": attendance.x_check_out_map,
                    "x_check_in_map": attendance.x_check_in_map,
                    "x_mobile": attendance.x_mobile,
                    "check_attendance_id": attendance.check_attendance_id,

                })
            return request.make_json_response({
                "message": "Attendance records retrieved successfully",
                "count": len(attendances),
                "data": result
            }, status=200)

        except Exception as error:
            return request.make_json_response({
                "error": str(error),
                "message": "Failed to retrieve attendance records"
            }, status=400)

    @http.route('/api/modules', type='http', auth='public', methods=['GET'],
                csrf=False)
    def get_modules(self, **kwargs):
        """
        Get all installed modules
        """
        modules = request.env['ir.module.module'].sudo().search(
            [('state', '=', 'installed')])
        data = [
            {'name': m.name, 'technical_name': m.name, 'shortdesc': m.shortdesc}
            for m in modules]
        return request.make_response(
            json.dumps(data, indent=4),
            headers=[('Content-Type', 'application/json')]
        )

    @http.route('/api/companies', type='http', auth='public', methods=['GET'],
                csrf=False)
    def get_companies(self, **kwargs):
        """
        Get all companies
        """
        companies = request.env['res.company'].sudo().search([])
        data = [{
            'id': c.id,
            'name': c.name,
            'currency': c.currency_id.name if c.currency_id else None,
            'partner_id': c.partner_id.id if c.partner_id else None,
        } for c in companies]
        return request.make_response(
            json.dumps(data, indent=4),
            headers=[('Content-Type', 'application/json')]
        )

    # @http.route('/api/get_partner/<string:number>', type='http', auth='public',
    #             methods=['GET'], csrf=False)
    # def get_partner_by_number(self, number, **kwargs):
    #     """
    #     Search partner by either phone or mobile number.
    #     Example: /api/get_partner/01012345678
    #     """
    #     if not number:
    #         return request.make_json_response({'error': 'Number is required.'},
    #                                           status=400)
    #
    #     # Search partner by phone OR mobile
    #     partner = request.env['res.partner'].sudo().search([
    #         '|', ('phone', '=', number), ('mobile', '=', number)
    #     ], limit=1)
    #
    #     if partner:
    #         data = {
    #             'partner_id': partner.id,
    #             'partner_name': partner.name,
    #             'phone': partner.phone,
    #             'mobile': partner.mobile,
    #         }
    #         return request.make_json_response(data)
    #     else:
    #         return request.make_json_response({'error': 'Partner not found.'},
    #                                           status=404)

    @http.route('/api/get_partner/<string:number>', type='http',
                auth='public', methods=['GET'], csrf=False)
    def get_partner_by_number(self, number, **kwargs):
        """
        Returns Cisco IP Phone Directory XML with partner name & phone number.
        Example: /api/get_partner/01012345678
        """
        if not number:
            xml_response = """<?xml version="1.0" encoding="UTF-8"?>
            <CiscoIPPhoneText>
                <Title>Error</Title>
                <Prompt>Missing number</Prompt>
                <Text>Number is required.</Text>
            </CiscoIPPhoneText>"""
            return request.make_response(xml_response, headers=[
                ('Content-Type', 'text/xml')])

        # Search by phone or mobile
        partner = request.env['res.partner'].sudo().search([
            '|', ('phone', '=', number), ('mobile', '=', number)
        ], limit=1)

        if partner:
            # if found
            xml_response = f"""<?xml version="1.0" encoding="UTF-8"?>
            <CiscoIPPhoneDirectory>
              <Title>My Corporate Directory</Title>
              <Prompt>Select a contact to dial</Prompt>
              <DirectoryEntry>
                <Name>{partner.name}</Name>
                <Telephone>{partner.mobile or partner.phone or ''}</Telephone>
              </DirectoryEntry>
            </CiscoIPPhoneDirectory>"""
        else:
            # not found
            xml_response = """<?xml version="1.0" encoding="UTF-8"?>
            <CiscoIPPhoneText>
              <Title>Not Found</Title>
              <Prompt>No contact found</Prompt>
              <Text>Partner not found for this number.</Text>
            </CiscoIPPhoneText>"""

        return request.make_response(xml_response,
                                     headers=[('Content-Type', 'text/xml')])
