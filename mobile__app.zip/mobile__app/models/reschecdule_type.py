from odoo import models, fields, api
class manger(models.Model):
    _name = 'reschedule.type'

    name = fields.Char()
