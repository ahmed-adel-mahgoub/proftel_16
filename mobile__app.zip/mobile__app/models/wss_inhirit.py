from odoo import fields,models,api

class wss(models.Model):
    _inherit = ''