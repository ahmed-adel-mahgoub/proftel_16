# -*- coding: utf-8 -*-

from odoo import models, fields, api


class permissions(models.Model):
    _name = 'permissions'
    _description = 'permissions'

    name = fields.Char()
    employee_id = fields.Many2one(
        'hr.employee',
        string="Employee"
    )
    department_id = fields.Char(related='employee_id.department_id.name',
                                string='Department'
                                , readonly=True)
    email = fields.Char(
        related='employee_id.work_email'
    )
    employee_company_id = fields.Many2one(
        'res.company',
        string="Employee's Company",
        related='employee_id.company_id',
    )
    task_read = fields.Boolean(string="Read")
    task_write = fields.Boolean(string="Write")
    task_update = fields.Boolean(string="Update")
    task_delete = fields.Boolean(string="Delete")
    task_ws = fields.Boolean(string="ws")

    attendance_read = fields.Boolean(string="Read")
    attendance_write = fields.Boolean(string="Write")
    attendance_update = fields.Boolean(string="Update")
    attendance_delete = fields.Boolean(string="Delete")
    attendance_ws = fields.Boolean(string="ws")

    transfer_read = fields.Boolean(string="Read")
    transfer_write = fields.Boolean(string="Write")
    transfer_update = fields.Boolean(string="Update")
    transfer_delete = fields.Boolean(string="Delete")
    transfer_ws = fields.Boolean(string="ws")

    expenses_read = fields.Boolean(string="Read")
    expenses_write = fields.Boolean(string="Write")
    expenses_update = fields.Boolean(string="Update")
    expenses_delete = fields.Boolean(string="Delete")
    expenses_ws = fields.Boolean(string="ws")

    transportation_read = fields.Boolean(string="Read")
    transportation_write = fields.Boolean(string="Write")
    transportation_update = fields.Boolean(string="Update")
    transportation_delete = fields.Boolean(string="Delete")
    transportation_ws = fields.Boolean(string="ws")

    connection_read = fields.Boolean(string="Read")
    connection_write = fields.Boolean(string="Write")
    connection_update = fields.Boolean(string="Update")
    connection_delete = fields.Boolean(string="Delete")
    connection_ws = fields.Boolean(string="ws")
